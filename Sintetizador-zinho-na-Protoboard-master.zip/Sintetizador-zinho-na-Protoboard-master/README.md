# Sintetizador-zinho-na-Protoboard

Músico Nerd

Tutorial completo em: http://www.musiconerd.com/single-post/2016/04/09/Como-Fazer-um-Sintetizadorzinho-na-protoboard-Arduino-Tutorial
